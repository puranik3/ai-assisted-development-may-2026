# DevAnswers Backend - AI Agent Instructions

A Question & Answer App built with Express.js and MongoDB.

## Quick Start

```bash
# Setup
npm install
cp .env.example .env  # Configure MONGODB_URI and JWT_SECRET

# Development
npm run dev           # Start with nodemon
npm start             # Start production
npm test              # Run all tests (Vitest)
npm run populate      # Seed database with sample data
```

## Architecture

**3-Layer Service Pattern**: Routes → Controllers → Services → Models

```
src/
├── routes/          # Express routers, apply middleware
├── controllers/     # Request/response handlers (thin layer)
├── services/        # Business logic, database operations
├── models/          # Mongoose schemas (User, Question, Answer, Tag)
└── middleware/      # Authentication, error handling
```

**Separation of concerns**:

- Controllers: Extract req data, call services, format responses
- Services: All business logic, throw errors with `createAppError(message, statusCode)`
- Models: Schema definitions only, no business logic

## API Patterns

**Base path**: `/api`

**Standard response format**:

```javascript
{ success: true, message: "...", data: {...} }  // Success
{ success: false, message: "..." }              // Error
```

**Routes**:

- `/api/auth` - Registration, login (public)
- `/api/questions` - CRUD, voting, view tracking
- `/api/questions/:questionId/answers` - Create answer
- `/api/answers` - Answer CRUD, voting
- `/api/tags` - Tag listing

**Protection pattern**:

- Public: All GET endpoints
- Protected: POST/PUT/DELETE (require `authenticate` middleware)

## Authentication & Authorization

**JWT-based**: Bearer token in `Authorization` header

```javascript
// Middleware sets req.user
req.user = { id: "userId", isAdmin: boolean };
```

**Authorization checks in services**:

```javascript
// Allow owner or admin
if (resource.author.toString() !== user.id && !user.isAdmin) {
  throw createAppError("Not authorized", 403);
}
```

**Password handling**: bcryptjs with 10 salt rounds

## Database Models

**Mongoose schemas** with key relationships:

- **User**: name, email, password (hashed), isAdmin, profileImage
- **Question**: title, description, tags[], author (ref), upvotes[], downvotes[], voteCount, views
- **Answer**: questionId (ref), answerText, author (ref), upvotes[], downvotes[], voteCount
- **Tag**: name (unique index)

**Voting pattern**: User ID arrays (`upvotes[]`, `downvotes[]`) + computed `voteCount`

## Error Handling

**All errors flow through global error handler middleware**:

```javascript
// Services throw errors with status codes
throw createAppError("Resource not found", 404);
throw createAppError("Not authorized", 403);

// Automatic handling (Express 5 catches async errors)
```

**Common status codes**:

- 400: Validation errors
- 401: Not authenticated
- 403: Not authorized (authenticated but no permission)
- 404: Resource not found
- 409: Conflict (e.g., duplicate email)

## Testing

**Framework**: Vitest with two test types:

**Integration tests** (`tests/integration/`):

- Use MongoDB Memory Server (in-memory database)
- Full HTTP requests via supertest
- Setup in `tests/setup.js` (global beforeAll/afterAll)

**Unit tests** (`tests/unit/`):

- Mock services and models with `vi.mock()`
- Test controllers/services/middleware in isolation
- Clear mocks in beforeEach

## Key Conventions

**Naming**:

- Services: `{action}{Resource}Service` → `createQuestionService(data, user)`
- Controllers: `{action}{Resource}` → `async createQuestion(req, res, next)`

**Voting logic** (`voteService.js`):

- Shared `handleVote(model, resourceId, userId, voteType)` for questions/answers
- Prevents duplicate votes, allows vote switching
- Atomic updates: remove old vote, add new, recalculate count

**Tag handling**:

- Auto-create tags from comma-separated input strings
- Deduplication via `findOne` before insert
- Return ObjectIds for question.tags array

**Population**:

- Author: `{ name }` only (exclude password, email)
- Tags: Full tag objects on questions
- Answers: Embedded in question detail responses

**Security**:

- Helmet for security headers
- Rate limiting: 100 requests per 15 minutes per IP
- CORS enabled
- 10MB body size limit

## Environment Variables

Required in `.env`:

- `PORT`: Server port (default: 3000)
- `MONGODB_URI`: MongoDB connection string
- `JWT_SECRET`: Secret for signing tokens (use strong random value)
- `JWT_EXPIRATION`: Token expiry (default: 7d)
- `NODE_ENV`: development/production
